# HalalBacon — Private Prospectus (v2) · Luma Storyboard

Scene-for-scene video plan mirroring the interactive prospectus (`prospectus.html`). Each scene in the deck = one video shot, so you can scrub the live experience to preview timing, then generate matching clips in **Luma Dream Machine**. Ten scenes, ~68s total.

---

## Global direction (every shot)
- **Look:** premium, calm, cinematic — Apple-keynote restraint. Real people, real green housing, soft natural light. Not crypto.
- **Grade:** deep green (#073F2E) + warm gold (#B88A2B) + cream (#F6EEDC), soft daylight, gently desaturated. No neon, no flags, no religious ornamentation, no on-screen crypto motifs.
- **Type (added in your editor):** Fraunces serif headlines, Hanken Grotesk / Inter body, gold botanical dividers.
- **Aspect:** 16:9 for web; also export 9:16 for reels.
- **Pacing:** ~6–7s per scene, slow confident moves only (push-in, drift, parallax).
- **Music:** warm, minimal, hopeful — felt piano / soft strings / low pulse.
- **Transitions:** gentle cross-dissolve or a 0.3s gold light-sweep.
- **Compliance (keep in VO + overlays):** participation / capacity / membership / utility / "example." Avoid invest / returns / yield / guaranteed. Keep the footer line on screen: *Invitation-only • Preliminary • Not legal, tax, securities, crypto, or investment advice.*

> **Text & numbers:** AI video won't render crisp text. For data scenes (Media Stack, Concierge, Pricing, Roles, Proof Loop, Roadmap), generate Luma as atmospheric B-roll and overlay the real text/numbers in your editor (CapCut / Premiere / AE). You can also drop the matching prospectus page in as a Luma **start keyframe** for subtle motion.

---

## Scene 1 — Cover  *(≈7s)*
- **On-screen text:** "Private Prospectus" · "Media. Community. Real Projects." · "Stop donating. Start participating."
- **Visual:** diverse community seated together in a lush green rooftop courtyard at golden hour; logo fades in.
- **Motion:** very slow push-in, faint parallax on foreground planting.
- **Luma prompt:** `Cinematic slow push-in on a diverse group sitting and talking warmly in a lush green rooftop garden at golden hour, soft sun flare, shallow depth of field, deep-green and warm-gold grade, calm and hopeful, photorealistic, 35mm`
- **VO:** "HalalBacon moves people from passive consumption into visible, community-backed impact."

## Scene 2 — Why we exist  *(≈6s)*
- **On-screen text:** "The old model asks for trust before showing proof." · Old model ✕ (4) vs HalalBacon model ✓ (4) · flow Media → Trust → Community → Projects → Impact
- **Visual:** cold boardroom "donations" dissolving into a warm, candid community-and-dashboard scene.
- **Motion:** left desaturates and recedes; right warms and advances; the five-step flow draws on.
- **Luma prompt:** `Cinematic transition from a cold grey corporate boardroom to a warm candid scene of diverse people reviewing a laptop dashboard and printed charts together outdoors, golden light replacing fluorescent light, deep-green and gold grade, photorealistic, slow dolly`
- **VO:** "The old model hides behind opacity. We flipped it: media builds trust, community funds projects, dashboards show impact."

## Scene 3 — The Media Stack  *(≈6s)*  *(overlay numbers in editor)*
- **On-screen text:** "Three media layers. One trust engine." · Fajr $88.88/mo ($777.88/yr) · Asr $28.88/mo ($222.88/yr) · Duhr $28.88/mo ($222.88/yr)
- **Visual:** three vertical glass panels rising over a sunrise → midday → dusk green city.
- **Motion:** panels rise and settle; light shifts dawn→day→dusk.
- **Luma prompt:** `Three tall translucent glass panels rising in sequence over a green city skyline as light shifts from sunrise to midday to dusk, soft gold reflections, cream-and-emerald palette, cinematic, photorealistic, slow upward camera`
- **VO:** "Fajr at dawn, Asr to filter the signal, Duhr for the community layer — one trust engine."

## Scene 4 — HBT Participation Layer  *(≈7s)*
- **On-screen text:** "Capacity, not hype." · "1 HBT = 25,000 USDT participation capacity" · Hold → Maintain 364 days → Unlock Fajr+Asr+Duhr → Choose → Repeat
- **Visual:** a gold seed/coin is held, a calendar ring completes, media unlocks, the cycle loops.
- **Motion:** macro push on the coin → 5-step ring rotates once and returns.
- **Luma prompt:** `Macro cinematic shot of a glowing gold coin held in an open hand, fine golden light forming a circular cycle that loops back to the hand, dark emerald background, warm rim light, photorealistic, calm, slow push-in`
- **VO:** "Hold one HBT, keep 364-day access, and all three editions unlock. Capacity — not a coin to trade."

## Scene 5 — Gift Card Utility + Concierge Agent  *(≈7s)*  *(overlay UI in editor)*
- **On-screen text:** "The moment you select a gift card, the utility layer unlocks." · gift-card destinations · concierge capabilities · "Increase purchasing power before reimbursement arrives."
- **Visual:** a gift card is chosen, then a clean phone dashboard (Concierge Agent) animates — price comparison, deal alerts, optimization.
- **Motion:** card slides in → phone screen lights up → metrics tick.
- **Luma prompt:** `Cinematic close-up of a premium smartphone on a warm wooden desk with a plant and coffee, screen glowing softly with an elegant shopping-assistant dashboard, deep-green and gold UI tones, shallow depth of field, photorealistic, gentle push-in`
- **VO:** "Pick a gift-card destination and the Concierge Agent unlocks — sourcing, deal monitoring, and optimization to stretch your purchasing power."

## Scene 6 — Pricing & Access  *(≈5s)*  *(overlay table in editor)*
- **On-screen text:** Direct media pricing table (Fajr / Asr / Duhr, monthly + yearly) · HBT access logic (Hold 1 HBT → unlock media · Select gift card → unlock Concierge · Maintain status → ecosystem access · Participate → track proof)
- **Visual:** soft cards sliding into a clean column over cream with gold edges; arrows connecting action → unlock.
- **Motion:** cards slide and align; arrows draw on.
- **Luma prompt:** `Minimal premium motion of cream cards with thin gold edges sliding and aligning into a tidy column on a warm textured surface, soft shadows, shallow depth of field, calm, cinematic, photorealistic`
- **VO:** "Buy the media directly — or let HBT and a gift-card selection unlock the whole ecosystem."

## Scene 7 — Community Roles  *(≈6s)*  *(overlay labels in editor)*
- **On-screen text:** Media Member 1 HBT · Community Participant 6 HBT · Project Reviewer 60 HBT · Generational Wealth (≥6 HBT/yr, accredited only) · "Move from reader to participant."
- **Visual:** four real portraits in soft light — reader, community trio, focused reviewer, multigenerational family.
- **Motion:** slow rack-focus across the four, each warming as it's in focus.
- **Luma prompt:** `Cinematic slow rack-focus across four warm portraits in soft daylight — a person reading on a tablet with coffee, three friends talking, a focused professional, a multigenerational family — deep-green and gold grade, photorealistic, shallow depth of field`
- **VO:** "Roles create structure — from readers to long-term builders."

## Scene 8 — The Proof Loop  *(≈7s)*  *(overlay counters in editor)*
- **On-screen text:** Media → Trust → Community → Projects → Impact · project categories · counters 128 · $2.48M · 342 · 5,764 (label *example*) · "Divest internationally. Invest locally. View your impact immediately."
- **Visual:** five vignettes connect in a ring; then a warm green city at dusk with a glowing dashboard, lights coming on across retrofitted homes.
- **Motion:** camera orbits the ring, then slow aerial drift; counters tick up.
- **Luma prompt:** `Slow orbital camera around five glowing circular vignettes connected by gold light trails, transitioning to a cinematic aerial drift over a green city at dusk with warm window lights switching on across solar-roofed homes, deep-green and gold tones, hopeful, photorealistic`
- **VO:** "Media earns trust, community funds projects, and the impact shows up on an open dashboard."

## Scene 9 — Go-To-Market Roadmap  *(≈6s)*  *(overlay phases in editor)*
- **On-screen text:** 01 waitlist + early-bird (24 months or 6 HBT) · 02 first Project Reviewer · 03 6 HBT · 04 60 HBT
- **Visual:** a gold path winding forward through four milestone markers in a green landscape.
- **Motion:** forward tracking shot; markers pass camera one by one.
- **Luma prompt:** `Cinematic forward tracking shot along a softly glowing gold path winding through a green landscape past four illuminated milestone markers, emerald-cream palette, calm, hopeful, photorealistic, smooth dolly`
- **VO:** "Read the signal. Choose the role. Participate in the proof."

## Scene 10 — Close / Join  *(≈7s)*
- **On-screen text:** "Move from reader to participant." · logo · *Invitation-only • Preliminary • Not legal, tax, securities, crypto, or investment advice*
- **Visual:** wide golden-hour view of a thriving green neighbourhood + skyline; community walking together.
- **Motion:** slow crane-up revealing the skyline; settle on logo.
- **Luma prompt:** `Cinematic slow crane-up revealing a thriving green neighbourhood with solar rooftops and a city skyline at golden sunset, diverse people walking together below, warm emerald-gold light, hopeful, photorealistic, premium`
- **VO:** "Media builds trust. HBT activates participation. Projects create proof. Move from reader to participant."

---

## Assembly checklist
1. Generate each scene in Luma (use the prompt; for data scenes drop the matching prospectus page as a **start keyframe** for subtle motion).
2. Use Luma **Extend** for longer clips; **Loop** for Scene 4's cycle.
3. Edit in scene order; trim to the durations above (~68s total).
4. Overlay headlines/numbers (Fraunces + Hanken) and the Scene 8 counters; keep text in a third with a gold divider.
5. Add VO + minimal music; place the gold light-sweep between scenes.
6. Keep the legal line on screen for Scene 10 (and small/persistent if used for paid promotion).
