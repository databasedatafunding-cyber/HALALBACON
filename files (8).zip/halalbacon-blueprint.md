# HALALBACON

### MVP Product Blueprint — An Internal Design Manifesto

*Radical clarity, delivered before the noise.*

A high-signal media intelligence system that strips left- and right-wing ideological theater to reveal objective market data — published at the absolute crack of dawn, ahead of the world's opening bells.

⸻

> **Doctrine.** We do not compete for attention. We remove it from the equation.
> Where the market sells outrage by the hour, we deliver structure once a day, early, and then go quiet.
> The product is not content. The product is *clarity under discipline.*

⸻

## 00 — Aesthetic Mandate

Three constraints govern every screen, sentence, and silence in the system.

**Restraint over persuasion.** Nothing animates to impress. Motion exists only to orient. White space is not empty; it is the most expensive material we own.

**Warmth over clinic.** We reject the cold blue-grey of the dashboard era. The surface is cream, the structure is deep organic green, the accents are warm gold. The product should feel like a private reading room at first light — not a trading terminal.

**Proof over promise.** Every claim resolves to a variable, a source, or a mechanic. We use the language of *capacity, participation, and systematic proof* — never the language of speculation.

⸻

## I — The Landing Page: Copy & Structural Rhythm

The page is read top-to-bottom like a single long exhale. Four movements. No carousel, no logo wall, no manufactured urgency.

### The Hero — *The Threshold*

> # Read the day before it is sold to you.
>
> #### HalalBacon publishes objective market reality at first light — stripped of left, right, and the theater in between. You arrive not as an audience, but as a participant with standing inside a disciplined intelligence network.

Quiet, confident, declarative. The subheadline introduces the two pillars early: *objective reality* and *participation with standing.* No "AI-powered," no "revolutionary," no exclamation.

A single thin gold rule sits beneath the hero. Below it, one line of structural copy:

> *One signal at dawn. Then silence until it matters.*

### The Great Divide — *The Paradox*

A two-column contrast, set as a calm comparison rather than an argument.

**The Attention Economy** manufactures conflict because conflict is liquid. It monetizes the gap between the left's framing and the right's framing, and sells you the friction as if it were news. The result is volume without information, and a population that is exhausted, certain, and uninformed in equal measure.

**The HalalBacon Paradigm** treats neutrality as an engineering requirement, not a personality. We do not balance two biases against each other; we extract the invariant facts that survive both. What remains is structural truth — the supply chain, the policy mechanic, the number — delivered calmly, once, and early.

> *They sell the noise. We dispose of it.*

### The Temporal Media Stack — *A Three-Part Delivery Architecture*

Publication is organized around a sacred temporal rhythm. Three layers, each with a distinct mandate, released in sequence across the arc of a day.

**Layer I · The Dawn Signal — *Fajr***
Raw macro clarity and market-readiness vectors, delivered at the first light of day, before the opening bells. This is the unprocessed signal: what moved overnight, what is mechanically true this morning, and the variables that will govern the session. No commentary. No forecast theater. Only the readiness vector.

**Layer II · The Midday Filter — *Asr***
The processing phase. The day's wire reports arrive charged with framing; the Filter aggressively de-noises them — dissolving the political theater, isolating the hard variables, and returning a zero-bias brief. This is where outrage is metabolized into information.

**Layer III · The Assembly — *Duhr***
The localized utility layer. Raw, neutral data is transformed into community proof and project-based velocity — translating global structure into local consequence. The Assembly is where intelligence becomes participation: dashboards, local housing and policy mechanics, and the visible record of what the network actually built.

⸻

## II — The Algorithmic Neutrality Framework

*How a charged global wire report becomes a Zero-Bias financial brief.*

Neutrality here is not editorial restraint applied by a sympathetic human. It is a deterministic pipeline that treats bias as **noise to be filtered** and hard variables as **signal to be preserved**. The objective is a brief in which two readers of opposing politics cannot identify which side the author favors — because the author favored neither; the author favored the variables.

### The Extraction Pipeline

```
SOURCE  →  NORMALIZE  →  DECOMPOSE  →  ISOLATE  →  STRIP  →  RECONCILE  →  SCORE  →  PUBLISH
```

**1 · Source & Provenance.** Ingest from primary instruments first — filings, central-bank releases, official statistics, exchange data — and treat secondary wires as claims, not facts. Every sentence inherits a provenance tag and a confidence weight.

**2 · Normalize.** Reduce each document to plain assertions. Strip layout, headline framing, and ordering effects, all of which encode editorial intent before a single word is read.

**3 · Decompose (Claim vs. Frame).** Separate every statement into its *claim* (a testable proposition) and its *frame* (the affective packaging around it). "Reckless spending bill" decomposes into the claim — a fiscal figure and its mechanism — and the frame — the adjective *reckless* and the noun *spending* as a moral verdict. The claim advances. The frame is quarantined.

**4 · Isolate Hard Variables.** Preserve only the invariants that survive any political reading:

- **Quantitative metrics** — figures, rates, deltas, volumes, durations.
- **Policy mechanics** — what the instrument actually does, procedurally, independent of who benefits.
- **Supply-chain realities** — inputs, capacities, bottlenecks, lead times, dependencies.
- **Counterparties & timelines** — who, by when, under what enforceable condition.

**5 · The De-Noising Protocol.** Surgically dispose of everything that carries slant and no information:

- **Adjective and adverb excision** — strip evaluative modifiers ("devastating," "historic," "reckless," "bold"). A number does not need an adjective; if it does, the adjective is the bias.
- **Modal and attribution audit** — collapse "could," "might," "experts fear," "critics warn" into either a sourced probability or deletion. Anonymous emotion is not a variable.
- **Weaponized-framing removal** — neutralize loaded constructions (agent-blaming, passive concealment, euphemism) back to the underlying mechanic.
- **Symmetry test** — rewrite the sentence as the opposing side would, then keep only what both versions assert in common.

**6 · Dual-Frame Reconciliation.** Run the decomposed claim through two adversarial readings — a maximally "left" and maximally "right" interpretation — and retain the intersection. Divergence between the two frames is, by definition, theater; the intersection is the structural fact. This is the core extraction: *bias is the difference; truth is the overlap.*

**7 · Residue Score.** Compute a **Bias Residue Index** — the proportion of affective, modal, and unsourced tokens remaining after the protocol. A brief does not publish above a hard residue ceiling. The score travels with the brief as a visible discipline metric.

**8 · Human Verification at Dawn.** A single editor confirms provenance and mechanic — not tone — and releases the Dawn Signal. The machine removes the noise; the human guarantees the source.

> *We do not moderate the debate. We delete it, and keep the data underneath.*

⸻

## III — The Capacity & Participation Matrix

Two ways in. The same discipline governs both: you are paying for clarity, or you are maintaining capacity for it. Neither is a wager.

### Direct Access — *Standard Membership*

A clean, premium subscription to the Temporal Stack. No bundles, no countdown timers, no founder-rate theater.

| Layer | Mandate | Monthly | Annual |
|:--|:--|:--:|:--:|
| **Fajr** — The Dawn Signal | Premium macro clarity & market-readiness, pre-bell | **$88.88** | **$777.88** |
| **Asr** — The Midday Filter | De-noised, zero-bias briefs from the day's wires | **$28.88** | **$222.88** |
| **Duhr** — The Assembly | Localized utility, community proof & project velocity | **$28.88** | **$222.88** |

*Annual members hold the full stack at a single disciplined rate. Pricing is fixed and legible; the only thing we ask you to optimize is your attention.*

### The Capacity Mechanism — *Ecosystem Access*

HalalBacon replaces speculative financial language with disciplined **capacity** language.

This is not a trading layer. This is not a yield product. This is not a promise of appreciation. **It is an ecosystem access mechanism.**

Maintaining a **verified balance of 1 HBT** — a single **Capacity Unit**, defined as **25,000 USDT of participation capacity** — unlocks full access to the HalalBacon Temporal Stack for the defined access period, replacing the traditional media paywall with **proof of participation**.

The member is no longer positioned only as a reader. They become a **verified participant** inside a structured intelligence and utility network — entitled to the full stack, the project dashboards, and standing inside the community layer for as long as the balance is maintained.

**Access logic, in four movements:**

- **Maintain a verified balance of 1 HBT** → the full Temporal Stack unlocks (Fajr · Asr · Duhr).
- **Select an ecosystem utility destination** → the Concierge utility layer unlocks.
- **Sustain the verified balance** → ecosystem access continues, renewably.
- **Participate in projects** → systematic proof and local impact become visible.

#### Approved Language

> **Use** — Capacity Unit · Verified Balance · Access Layer · Membership Proof · Participation Capacity · Ecosystem Utility · Proof of Capacity · Structured Access
>
> **Avoid** — Token holder · Crypto investor · Trading upside · Yield · Market cap · Pump · Passive return · Guaranteed benefit

#### Compliance Line

> *HBT is presented as an ecosystem access and capacity mechanism, not as a speculative asset, investment product, or promise of return.*
>
> *Invitation-only • Preliminary • Not legal, tax, securities, crypto, or investment advice.*

⸻

## IV — Visual Language & Tailwind / CSS Codex

A calming, organic, profoundly premium system. Warm where the category is cold; quiet where the category shouts.

### The Palette

| Token | Hex | Role |
|:--|:--|:--|
| **Deep Green** | `#073F2E` | Primary structure, dark surfaces, authority |
| **Emerald** | `#0F6B4A` | Secondary green, accents on light |
| **Gold** | `#B88A2B` | Primary accent, rules, emphasis |
| **Soft Gold** | `#D8B867` | Accent-on-dark, hairlines, highlights |
| **Cream** | `#F6EEDC` | Primary background — the reading surface |
| **Warm White** | `#FFFDF7` | Elevated cards on cream |
| **Charcoal** | `#1E1E1E` | Body text on light |
| **Muted Red** | `#B84A3A` | Reserved — used only for the "old model," never for alerts-as-theater |

The discipline: **green carries structure, gold carries emphasis, cream carries calm.** Red is rationed almost to absence.

### Typography

- **Fraunces** — the literary, authoritative serif. Headlines only. Heavy optical size, tight tracking (`-0.04em`), near-1.0 line-height. It should feel set in metal, not rendered in a browser.
- **Hanken Grotesk** (Inter as fallback) — the sharp geometric sans for all data, UI, and body. Legible at the smallest sizes; invisible as a personality.

> Serif commands. Sans informs. They never trade roles.

### Dividers & Ornament

Structure is separated by **thin gold rules** (1px, `#B88A2B` at 30–40% opacity) and the occasional **botanical glyph** (a single leaf mark, centered) to mark a major threshold. Ornament is an event, not a texture.

### Design Tokens — `:root`

```css
:root {
  /* color */
  --green-deep:  #073F2E;
  --green-black: #02241D;
  --emerald:     #0F6B4A;
  --gold:        #B88A2B;
  --gold-soft:   #D8B867;
  --cream:       #F6EEDC;
  --warm-white:  #FFFDF7;
  --charcoal:    #1E1E1E;
  --muted-red:   #B84A3A;

  --line-gold:   rgba(184, 138, 43, 0.32);
  --line-ink:    rgba(30, 30, 30, 0.12);

  /* type */
  --font-serif:  "Fraunces", Georgia, serif;
  --font-sans:   "Hanken Grotesk", "Inter", system-ui, sans-serif;
  --track-head:  -0.04em;
  --leading-head: 0.98;

  /* form */
  --radius-lg:   28px;
  --radius-md:   18px;
  --radius-sm:   12px;
  --space-section: clamp(96px, 12vw, 180px);

  /* motion — orient, never perform */
  --ease:        cubic-bezier(0.22, 1, 0.36, 1);
  --dur:         0.7s;
}
```

### Tailwind — `tailwind.config.js`

```js
module.exports = {
  theme: {
    extend: {
      colors: {
        green: { deep: "#073F2E", black: "#02241D", emerald: "#0F6B4A" },
        gold:  { DEFAULT: "#B88A2B", soft: "#D8B867" },
        cream: "#F6EEDC",
        warm:  "#FFFDF7",
        ink:   "#1E1E1E",
        clay:  "#B84A3A",
      },
      fontFamily: {
        serif: ['Fraunces', 'Georgia', 'serif'],
        sans:  ['Hanken Grotesk', 'Inter', 'system-ui', 'sans-serif'],
      },
      letterSpacing: { tightest: '-0.04em' },
      borderRadius: { xl2: '28px' },
      boxShadow: { soft: '0 24px 60px rgba(7,63,46,0.10)' },
      transitionTimingFunction: { calm: 'cubic-bezier(0.22,1,0.36,1)' },
    },
  },
};
```

### Component Grammar (MVP surface)

- **Surfaces** rest on `cream`; elevated cards use `warm-white` with a `soft` shadow and a hairline gold border.
- **The Dawn Signal card** is the one dark object on the page — `green-deep` on cream — so the eye lands on the morning brief first.
- **Buttons**: a single gold primary (`gold` → `gold-soft` gradient, ink text) and a quiet ghost outline. Never more than one primary in view.
- **Data UI** is monochrome green-on-cream; the Bias Residue Index is the only metric permitted a colored accent.

⸻

## Closing — The Standard

A reader should be able to open HalalBacon at dawn, spend four quiet minutes, and close it knowing what is *structurally true* about the day — without ever being told how to feel about it.

That is the entire product.

> *They sell the noise. We dispose of it. What remains is yours.*

⸻

*Invitation-only • Preliminary • Not legal, tax, securities, crypto, or investment advice. HBT is an ecosystem access and capacity mechanism, not a speculative asset, investment product, or promise of return.*
