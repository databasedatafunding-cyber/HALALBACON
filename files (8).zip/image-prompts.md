# HalalBacon — Photorealistic Image Prompts (v5 landing)

Drop the generated files into an `assets/` folder next to `index-v5.html`, using the **exact filenames** below. Each slot already has a hand-built SVG fallback, so the page looks complete until you add the photo — and the moment the file exists, the photo takes over automatically.

**House style for every prompt** (append to each): *hyper-realistic, photorealistic, premium Apple-keynote aesthetic, cinematic natural lighting, high resolution, realistic materials, minimalist composition, calm and institutional, palette of deep emerald green, warm gold, cream, and soft daylight. No text, no logos, no watermarks, no UI overlays. Avoid: cartoon, 3D render look, clipart, stock-photo cheesiness, neon, crypto motifs, religious ornamentation, flags.*

---

## 1. `assets/hero-housing.jpg` — Hero visual (≈ 320×170, landscape)
> A row of restored heritage-style townhouses with discreet solar panels on the rooftops, framed by young street trees at golden hour. A few diverse residents walk calmly on a clean sidewalk. Warm low sun, long soft shadows, quiet luxury, documentary realism. Emerald-and-gold daylight grade.

## 2. `assets/role-media-member.jpg` — Role: Media Member (≈ 340×170, landscape)
> A warm, relaxed reader holding a tablet and a cup of coffee by a window in soft morning light, shallow depth of field, calm and intelligent mood. Neutral premium interior, cream and emerald tones.

## 3. `assets/role-community-participant.jpg` — Role: Community Participant (≈ 340×170)
> An optimistic, dignified portrait of a diverse community member outdoors in soft daylight, genuine subtle smile, looking toward the light. Editorial, hopeful, grounded — not corporate stock.

## 4. `assets/role-project-reviewer.jpg` — Role: Project Reviewer (≈ 340×170)
> An analyst reviewing printed project documents and a laptop at a clean desk in a premium, quiet workspace, focused expression, warm task lighting, architectural plans faintly visible. Serious, competent, institutional.

## 5. `assets/role-generational-wealth.jpg` — Role: Generational Wealth (≈ 340×170)
> A warm multigenerational family on the steps of a restored heritage home at golden hour, dignity-first, natural candid moment, soft sun. Belonging and continuity, not wealth display.

## 6. `assets/cta-cityscape.jpg` — Final CTA background (wide, ≈ 1200×400)
> A wide cinematic cityscape at soft sunset: a skyline of mid-rise heritage and modern buildings with solar rooftops, warm amber sky fading to deep emerald dusk. Atmospheric, hopeful, calm. Lots of clean negative sky at the top for overlaid text. Subtle, slightly desaturated premium grade.

---

### Notes
- Aspect ratios are guidance; the slots use `object-fit: cover`, so close ratios are fine.
- Keep people candid and real — avoid the over-lit, over-smiling corporate-stock look the brand brief rules out.
- If you want a matched set, generate all six in one session with the same lighting/grade so they feel like one campaign.
- The four role images are the highest-impact swaps; do those first.
