# HalalBacon MVP Builder — Claude Skill

This is a Claude/Claude Code skill package for generating the HalalBacon MVP with:

- Next.js App Router
- Supabase Auth + Postgres + RLS
- Stripe Checkout + Customer Portal + webhooks
- Early-Bird onboarding
- HBT capacity onboarding
- Gift-card preference workflow
- Shopping-list concierge
- Infrastructure proof ledger

## Import into Claude

1. Zip the `halalbacon_claude_skill` folder.
2. Import/upload it as a custom Claude Skill.
3. Ask Claude: “Use the HalalBacon MVP Builder skill to create the Next.js + Supabase + Stripe MVP.”

## Install for Claude Code

Place the folder in one of the Claude Code skill locations supported by your setup, such as your project-level skills folder or personal skills folder, then restart Claude Code if needed.

## Suggested first prompt

Use the HalalBacon MVP Builder skill. Create a production-ready Next.js MVP with Supabase Auth, Stripe Early-Bird Checkout, user dashboard, HBT capacity reservation workflow, gift-card preference form, shopping-list concierge, admin dashboard, Supabase schema, RLS policies, and deployment checklist.
