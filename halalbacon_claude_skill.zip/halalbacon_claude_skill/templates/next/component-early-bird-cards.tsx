export function EarlyBirdCards() {
  return (
    <section className="rounded-[2rem] bg-[#FFFDF7] p-8 shadow-xl">
      <p className="text-sm uppercase tracking-[0.18em] text-[#B88A2B]">Founding participation</p>
      <h2 className="mt-3 font-serif text-5xl text-[#073F2E]">Choose your path.</h2>
      <p className="mt-3 max-w-2xl text-[#1E1E1E]/70">
        Two simple ways to support the journey: Early-Bird access for 12 months, or a verified HBT capacity path for 364 days.
      </p>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        <article className="rounded-3xl bg-[#073F2E] p-6 text-[#FFFDF7]">
          <div className="text-sm uppercase tracking-widest text-[#D8B867]">Option A</div>
          <h3 className="mt-4 font-serif text-4xl">Early-Bird</h3>
          <p className="mt-1 text-2xl text-[#D8B867]">12 months</p>
          <p className="mt-4 text-[#FFFDF7]/75">Support the journey and unlock the full Temporal Stack.</p>
          <button className="mt-8 w-full rounded-full bg-[#D8B867] px-5 py-4 font-bold text-[#073F2E]">Reserve Early-Bird</button>
        </article>

        <article className="rounded-3xl border border-[#B88A2B]/40 bg-[#F6EEDC] p-6 text-[#073F2E]">
          <div className="text-sm uppercase tracking-widest text-[#B88A2B]">Option B</div>
          <h3 className="mt-4 font-serif text-4xl">Capacity Path</h3>
          <p className="mt-1 text-2xl text-[#B88A2B]">1 HBT · 364 days</p>
          <p className="mt-4 text-[#1E1E1E]/70">Verify capacity, choose your preference, and unlock access subject to final terms.</p>
          <button className="mt-8 w-full rounded-full bg-[#073F2E] px-5 py-4 font-bold text-[#FFFDF7]">Choose HBT Access</button>
        </article>
      </div>

      <p className="mt-6 text-xs leading-relaxed text-[#1E1E1E]/55">
        HBT is presented as an ecosystem access and capacity mechanism, not as a speculative asset, investment product, deposit product, securities offering, crypto investment, or promise of return.
      </p>
    </section>
  )
}
