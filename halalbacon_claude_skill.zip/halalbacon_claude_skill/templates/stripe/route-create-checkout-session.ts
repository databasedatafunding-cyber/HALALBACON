import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2025-02-24.acacia',
})

const PRICE_BY_PACKAGE: Record<string, string | undefined> = {
  early_bird_12m: process.env.STRIPE_EARLY_BIRD_PRICE_ID,
  fajr: process.env.STRIPE_FAJR_PRICE_ID,
  duhr: process.env.STRIPE_DUHR_PRICE_ID,
  asr: process.env.STRIPE_ASR_PRICE_ID,
  full_stack: process.env.STRIPE_FULL_STACK_PRICE_ID,
}

export async function POST(req: NextRequest) {
  const { packageCode } = await req.json()

  if (!packageCode || !PRICE_BY_PACKAGE[packageCode]) {
    return NextResponse.json({ error: 'Invalid package.' }, { status: 400 })
  }

  if (packageCode.includes('hbt')) {
    return NextResponse.json({ error: 'HBT capacity is reserved through onboarding, not Stripe Checkout.' }, { status: 400 })
  }

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const admin = createAdminClient()
  const { data: existingCustomer } = await admin
    .from('stripe_customers')
    .select('stripe_customer_id')
    .eq('user_id', user.id)
    .maybeSingle()

  let customerId = existingCustomer?.stripe_customer_id

  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email || undefined,
      metadata: { user_id: user.id },
    })
    customerId = customer.id
    await admin.from('stripe_customers').insert({
      user_id: user.id,
      stripe_customer_id: customerId,
    })
  }

  const session = await stripe.checkout.sessions.create({
    mode: packageCode === 'early_bird_12m' ? 'payment' : 'subscription',
    customer: customerId,
    line_items: [{ price: PRICE_BY_PACKAGE[packageCode]!, quantity: 1 }],
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?checkout=success`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/early-bird?checkout=cancelled`,
    metadata: {
      user_id: user.id,
      package_code: packageCode,
      access_type: packageCode === 'early_bird_12m' ? 'early_bird' : 'subscription',
    },
  })

  await admin.from('stripe_checkout_sessions').insert({
    user_id: user.id,
    stripe_session_id: session.id,
    package_code: packageCode,
    status: session.status,
    amount_total: session.amount_total,
    currency: session.currency,
  })

  return NextResponse.json({ url: session.url })
}
