import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createAdminClient } from '@/lib/supabase/admin'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2025-02-24.acacia',
})

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = req.headers.get('stripe-signature')

  if (!signature) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 })
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    return NextResponse.json({ error: 'Invalid webhook signature' }, { status: 400 })
  }

  const admin = createAdminClient()

  await admin.from('stripe_webhook_events').upsert({
    stripe_event_id: event.id,
    event_type: event.type,
    payload: event as any,
    processed: false,
  }, { onConflict: 'stripe_event_id' })

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session
    const userId = session.metadata?.user_id
    const packageCode = session.metadata?.package_code
    const accessType = session.metadata?.access_type as any

    if (userId && packageCode && accessType) {
      const endsAt = new Date()
      if (packageCode === 'early_bird_12m') endsAt.setDate(endsAt.getDate() + 365)

      await admin.from('user_access').insert({
        user_id: userId,
        package_code: packageCode,
        access_kind: accessType,
        status: 'active',
        starts_at: new Date().toISOString(),
        ends_at: packageCode === 'early_bird_12m' ? endsAt.toISOString() : null,
        source: 'stripe_checkout',
        metadata: { stripe_session_id: session.id },
      })

      await admin.from('profiles').update({ role: 'member' }).eq('id', userId)
    }
  }

  await admin.from('stripe_webhook_events').update({ processed: true }).eq('stripe_event_id', event.id)

  return NextResponse.json({ received: true })
}
