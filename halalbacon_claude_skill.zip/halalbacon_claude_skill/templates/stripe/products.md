# Stripe Product Setup

Create Stripe products/prices for fiat access only.

## Products

### Early-Bird 12-Month Access

- Product: HalalBacon Early-Bird Access
- Billing: one-time or 12-month subscription depending on legal/accounting preference
- Metadata:
  - package_code: early_bird_12m
  - access_type: early_bird
  - duration_days: 365

### Fajr

- Product: HalalBacon Fajr
- Monthly price: 88.88
- Annual price: 777.88
- Metadata:
  - package_code: fajr

### Duhr

- Product: HalalBacon Duhr
- Monthly price: 28.88
- Annual price: 222.88
- Metadata:
  - package_code: duhr

### Asr

- Product: HalalBacon Asr
- Monthly price: 28.88
- Annual price: 222.88
- Metadata:
  - package_code: asr

### Full Stack

- Product: HalalBacon Full Stack
- Monthly price: 128.88
- Annual price: 999.88
- Metadata:
  - package_code: full_stack

## HBT Capacity

Do not create a public Stripe payment product for HBT by default.
Use an application/reservation flow unless legal and Stripe account review approve the final mechanism.
