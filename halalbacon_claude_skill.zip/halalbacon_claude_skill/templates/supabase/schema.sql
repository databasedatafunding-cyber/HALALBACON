-- HalalBacon Supabase MVP Schema
-- Run in Supabase SQL editor after enabling auth.

create extension if not exists "pgcrypto";

-- ---------- ENUMS ----------
do $$ begin
  create type public.user_role as enum ('user', 'member', 'admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.application_status as enum ('draft', 'submitted', 'under_review', 'approved', 'rejected', 'needs_info');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.access_type as enum ('early_bird', 'subscription', 'hbt_capacity', 'admin_grant');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.capacity_status as enum ('reserved', 'pending_verification', 'verified', 'active', 'completed', 'cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.shopping_status as enum ('draft', 'submitted', 'searching', 'matched', 'fulfilled', 'cancelled');
exception when duplicate_object then null; end $$;

-- ---------- HELPERS ----------
create or replace function public.is_admin(uid uuid default auth.uid())
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = uid and p.role = 'admin'
  );
$$;

-- ---------- PROFILES ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  preferred_language text default 'en',
  country text,
  role public.user_role not null default 'user',
  user_type text,
  interests text[] default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own_or_admin"
  on public.profiles for select
  using (id = auth.uid() or public.is_admin());

create policy "profiles_update_own_or_admin"
  on public.profiles for update
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());

create policy "profiles_insert_own"
  on public.profiles for insert
  with check (id = auth.uid());

-- ---------- ACCESS PACKAGES ----------
create table if not exists public.access_packages (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  description text,
  access_kind public.access_type not null,
  duration_days int,
  monthly_price_cents int,
  annual_price_cents int,
  stripe_price_id text,
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

alter table public.access_packages enable row level security;

create policy "access_packages_public_read_active"
  on public.access_packages for select
  using (is_active = true or public.is_admin());

create policy "access_packages_admin_all"
  on public.access_packages for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- USER ACCESS ----------
create table if not exists public.user_access (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  package_code text not null,
  access_kind public.access_type not null,
  status text not null default 'active',
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  source text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.user_access enable row level security;

create policy "user_access_select_own_or_admin"
  on public.user_access for select
  using (user_id = auth.uid() or public.is_admin());

create policy "user_access_admin_all"
  on public.user_access for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- ONBOARDING APPLICATIONS ----------
create table if not exists public.onboarding_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  path text not null check (path in ('early_bird_12m', 'hbt_capacity_364d')),
  status public.application_status not null default 'draft',
  user_type text,
  country text,
  intent text,
  compliance_ack boolean not null default false,
  submitted_at timestamptz,
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id),
  admin_notes text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.onboarding_applications enable row level security;

create policy "applications_select_own_or_admin"
  on public.onboarding_applications for select
  using (user_id = auth.uid() or public.is_admin());

create policy "applications_insert_own"
  on public.onboarding_applications for insert
  with check (user_id = auth.uid());

create policy "applications_update_own_draft_or_admin"
  on public.onboarding_applications for update
  using ((user_id = auth.uid() and status in ('draft','needs_info')) or public.is_admin())
  with check ((user_id = auth.uid()) or public.is_admin());

-- ---------- HBT CAPACITY ----------
create table if not exists public.hbt_capacity_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  application_id uuid references public.onboarding_applications(id) on delete set null,
  hbt_units numeric(18,6) not null default 1,
  usdt_capacity numeric(18,2) not null default 25000,
  term_days int not null default 364,
  status public.capacity_status not null default 'reserved',
  verified_at timestamptz,
  verified_by uuid references public.profiles(id),
  starts_at timestamptz,
  matures_at timestamptz,
  completion_preference text check (completion_preference in ('gift_card_preference','shopping_credit_adjustment','continue_hbt_capacity') or completion_preference is null),
  compliance_ack boolean not null default false,
  notes text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.hbt_capacity_records enable row level security;

create policy "hbt_select_own_or_admin"
  on public.hbt_capacity_records for select
  using (user_id = auth.uid() or public.is_admin());

create policy "hbt_insert_own"
  on public.hbt_capacity_records for insert
  with check (user_id = auth.uid());

create policy "hbt_update_own_reserved_or_admin"
  on public.hbt_capacity_records for update
  using ((user_id = auth.uid() and status in ('reserved','pending_verification')) or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

-- ---------- GIFT CARD PREFERENCES ----------
create table if not exists public.gift_card_preferences (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  hbt_capacity_record_id uuid references public.hbt_capacity_records(id) on delete cascade,
  preferred_brand text,
  preferred_category text,
  preferred_currency text default 'CAD',
  backup_brand text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.gift_card_preferences enable row level security;

create policy "gift_select_own_or_admin"
  on public.gift_card_preferences for select
  using (user_id = auth.uid() or public.is_admin());

create policy "gift_insert_own"
  on public.gift_card_preferences for insert
  with check (user_id = auth.uid());

create policy "gift_update_own_or_admin"
  on public.gift_card_preferences for update
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

-- ---------- SHOPPING LIST CONCIERGE ----------
create table if not exists public.shopping_lists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default 'My Concierge List',
  status public.shopping_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.shopping_lists enable row level security;

create policy "shopping_lists_select_own_or_admin"
  on public.shopping_lists for select
  using (user_id = auth.uid() or public.is_admin());

create policy "shopping_lists_insert_own"
  on public.shopping_lists for insert
  with check (user_id = auth.uid());

create policy "shopping_lists_update_own_or_admin"
  on public.shopping_lists for update
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

create table if not exists public.shopping_list_items (
  id uuid primary key default gen_random_uuid(),
  shopping_list_id uuid not null references public.shopping_lists(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_name text not null,
  story text,
  category text,
  target_budget_cents int,
  preferred_currency text default 'CAD',
  condition_preference text,
  authenticity_required boolean default false,
  urgency text check (urgency in ('low','normal','high') or urgency is null),
  status public.shopping_status not null default 'submitted',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.shopping_list_items enable row level security;

create policy "shopping_items_select_own_or_admin"
  on public.shopping_list_items for select
  using (user_id = auth.uid() or public.is_admin());

create policy "shopping_items_insert_own"
  on public.shopping_list_items for insert
  with check (user_id = auth.uid());

create policy "shopping_items_update_own_or_admin"
  on public.shopping_list_items for update
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

create table if not exists public.concierge_matches (
  id uuid primary key default gen_random_uuid(),
  shopping_list_item_id uuid not null references public.shopping_list_items(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  merchant_name text,
  merchant_url text,
  price_cents int,
  currency text default 'CAD',
  discount_estimate_percent numeric(5,2),
  authenticity_notes text,
  admin_notes text,
  is_visible_to_user boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.concierge_matches enable row level security;

create policy "concierge_select_visible_own_or_admin"
  on public.concierge_matches for select
  using ((user_id = auth.uid() and is_visible_to_user = true) or public.is_admin());

create policy "concierge_admin_all"
  on public.concierge_matches for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- BRIEFS ----------
create table if not exists public.briefs (
  id uuid primary key default gen_random_uuid(),
  layer text not null check (layer in ('fajr','duhr','asr')),
  title text not null,
  summary text,
  release_window text,
  bias_residue_percent numeric(5,2),
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.briefs enable row level security;

create policy "briefs_public_read_published"
  on public.briefs for select
  using (is_published = true or public.is_admin());

create policy "briefs_admin_all"
  on public.briefs for all
  using (public.is_admin())
  with check (public.is_admin());

create table if not exists public.brief_vectors (
  id uuid primary key default gen_random_uuid(),
  brief_id uuid not null references public.briefs(id) on delete cascade,
  label text not null,
  value text,
  delta text,
  sort_order int not null default 0
);

alter table public.brief_vectors enable row level security;

create policy "brief_vectors_public_read_if_brief_published"
  on public.brief_vectors for select
  using (exists (select 1 from public.briefs b where b.id = brief_id and (b.is_published = true or public.is_admin())));

create policy "brief_vectors_admin_all"
  on public.brief_vectors for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- INFRASTRUCTURE PROOF ----------
create table if not exists public.infrastructure_projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  location text,
  project_type text,
  status text,
  description text,
  published boolean not null default false,
  metrics jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.infrastructure_projects enable row level security;

create policy "projects_public_read_published"
  on public.infrastructure_projects for select
  using (published = true or public.is_admin());

create policy "projects_admin_all"
  on public.infrastructure_projects for all
  using (public.is_admin())
  with check (public.is_admin());

create table if not exists public.proof_events (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references public.infrastructure_projects(id) on delete cascade,
  title text not null,
  event_type text,
  description text,
  occurred_at date,
  evidence_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.proof_events enable row level security;

create policy "proof_public_read_published"
  on public.proof_events for select
  using (published = true or public.is_admin());

create policy "proof_admin_all"
  on public.proof_events for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- ART SUPPORT ORDERS ----------
create table if not exists public.art_support_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  title text not null,
  amount_cents int not null,
  currency text not null default 'CAD',
  stripe_checkout_session_id text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

alter table public.art_support_orders enable row level security;

create policy "art_orders_select_own_or_admin"
  on public.art_support_orders for select
  using (user_id = auth.uid() or public.is_admin());

create policy "art_orders_insert_own"
  on public.art_support_orders for insert
  with check (user_id = auth.uid());

create policy "art_orders_admin_all"
  on public.art_support_orders for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- STRIPE ----------
create table if not exists public.stripe_customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references public.profiles(id) on delete cascade,
  stripe_customer_id text unique not null,
  created_at timestamptz not null default now()
);

alter table public.stripe_customers enable row level security;

create policy "stripe_customers_select_own_or_admin"
  on public.stripe_customers for select
  using (user_id = auth.uid() or public.is_admin());

create policy "stripe_customers_admin_all"
  on public.stripe_customers for all
  using (public.is_admin())
  with check (public.is_admin());

create table if not exists public.stripe_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  stripe_subscription_id text unique,
  stripe_customer_id text,
  stripe_price_id text,
  package_code text,
  status text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.stripe_subscriptions enable row level security;

create policy "stripe_subscriptions_select_own_or_admin"
  on public.stripe_subscriptions for select
  using (user_id = auth.uid() or public.is_admin());

create policy "stripe_subscriptions_admin_all"
  on public.stripe_subscriptions for all
  using (public.is_admin())
  with check (public.is_admin());

create table if not exists public.stripe_checkout_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  stripe_session_id text unique not null,
  package_code text,
  status text,
  amount_total int,
  currency text,
  created_at timestamptz not null default now()
);

alter table public.stripe_checkout_sessions enable row level security;

create policy "stripe_sessions_select_own_or_admin"
  on public.stripe_checkout_sessions for select
  using (user_id = auth.uid() or public.is_admin());

create policy "stripe_sessions_admin_all"
  on public.stripe_checkout_sessions for all
  using (public.is_admin())
  with check (public.is_admin());

create table if not exists public.stripe_webhook_events (
  id uuid primary key default gen_random_uuid(),
  stripe_event_id text unique not null,
  event_type text not null,
  processed boolean not null default false,
  payload jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.stripe_webhook_events enable row level security;

create policy "stripe_webhooks_admin_only"
  on public.stripe_webhook_events for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- AUDIT ----------
create table if not exists public.audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  event_name text not null,
  entity_type text,
  entity_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

alter table public.audit_events enable row level security;

create policy "audit_admin_only"
  on public.audit_events for all
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- UPDATED_AT TRIGGER ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare r record;
begin
  for r in select tablename from pg_tables where schemaname = 'public' and tablename in (
    'profiles','user_access','onboarding_applications','hbt_capacity_records','gift_card_preferences','shopping_lists','shopping_list_items','infrastructure_projects','stripe_subscriptions'
  ) loop
    execute format('drop trigger if exists set_%I_updated_at on public.%I', r.tablename, r.tablename);
    execute format('create trigger set_%I_updated_at before update on public.%I for each row execute function public.set_updated_at()', r.tablename, r.tablename);
  end loop;
end $$;

-- ---------- PROFILE CREATION ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
