insert into public.access_packages (code, name, description, access_kind, duration_days, monthly_price_cents, annual_price_cents, sort_order)
values
  ('early_bird_12m', 'Early-Bird Access', '12 months of full-stack access to support the journey.', 'early_bird', 365, null, null, 1),
  ('fajr', 'Fajr', 'Dawn macro clarity and market-readiness vectors.', 'subscription', null, 8888, 77788, 2),
  ('duhr', 'Duhr', 'Midday filtering and de-noised briefs.', 'subscription', null, 2888, 22288, 3),
  ('asr', 'Asr', 'Local assembly proof and project velocity.', 'subscription', null, 2888, 22288, 4),
  ('full_stack', 'Full Stack', 'The complete Temporal Stack.', 'subscription', null, 12888, 99988, 5),
  ('hbt_capacity_364d', 'HBT Capacity Path', '1 HBT verified capacity path for 364 days, subject to final terms.', 'hbt_capacity', 364, null, null, 6)
on conflict (code) do update set
  name = excluded.name,
  description = excluded.description,
  access_kind = excluded.access_kind,
  duration_days = excluded.duration_days,
  monthly_price_cents = excluded.monthly_price_cents,
  annual_price_cents = excluded.annual_price_cents,
  sort_order = excluded.sort_order;

insert into public.briefs (layer, title, summary, release_window, bias_residue_percent, is_published, published_at)
values
  ('fajr', 'The Dawn Signal', 'Raw macro clarity before the world opens its mouth.', '04:48 EST', 8, true, now()),
  ('duhr', 'The Midday Filter', 'Charged narratives are filtered into variables.', '12:28 EST', 6, true, now()),
  ('asr', 'The Assembly', 'Macro signals become local consequence.', '15:42 EST', 12, true, now());
