# Technical Architecture

## Frontend

Next.js App Router with TypeScript and Tailwind.

Recommended folders:

- app/(public)
- app/(auth)
- app/dashboard
- app/admin
- app/api/stripe
- components/ui
- components/landing
- components/dashboard
- lib/supabase
- lib/stripe
- lib/auth

## Auth

Use Supabase Auth.

- Magic link or email/password.
- Profile row auto-created on first login.
- Role stored in profiles.role.

Roles:

- user
- member
- admin

## Database

Use Supabase Postgres with RLS.

Users can access only their own data.
Admins can manage all data.

## Payments

Stripe Checkout for Early-Bird and subscriptions.

Stripe webhook updates:

- stripe_customers
- stripe_subscriptions
- user_access
- audit_events

## HBT Capacity

HBT is not processed as a Stripe payment by default. It is handled through an onboarding/reservation and verification workflow.

Records live in:

- onboarding_applications
- hbt_capacity_records
- gift_card_preferences

## Shopping Concierge

Tables:

- shopping_lists
- shopping_list_items
- concierge_matches

Users submit requests. Admins add matches and partner purchase options.

## Proof Ledger

Tables:

- infrastructure_projects
- proof_events

Public proof page reads published projects/events only.
Admin can manage all proof records.
