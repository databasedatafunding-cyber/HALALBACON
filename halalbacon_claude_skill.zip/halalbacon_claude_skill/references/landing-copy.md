# Landing Copy

## Hero

Read the day before it is sold to you.

Objective market reality at first light — calm, simple, and clear.

One signal at dawn. Then silence until it matters.

Primary CTA: Enter the Signal
Secondary CTA: Start Early-Bird Onboarding

## Dawn Signal

Dawn Signal · Fajr
Pre-bell reality brief
04:48 EST

Energy: Brent pressure remains supply-driven. +2.1%
Rates: Policy path unchanged after overnight comments. 0 bps
Housing: Permit velocity below replacement threshold. -6.4%
Bias Residue Index: 8%

## Great Divide

The market is not confused. The media layer is.

The Attention Economy manufactures conflict because conflict is liquid.

The HalalBacon Paradigm treats neutrality as an engineering requirement, not a personality. We extract the invariant facts that survive opposing frames.

## Temporal Stack

Fajr — Dawn Signal — What moved overnight.
Duhr — Midday Filter — What is noise, what is real.
Asr — Assembly — What it means locally.

## Early-Bird

Founding participation is open.

Choose your path:

- Early-Bird — 12 months of full-stack access.
- Capacity Path — 1 HBT for 364 days, subject to verification and final terms.

Four steps:

1. Reserve
2. Verify
3. Maintain
4. Unlock

## HBT Disclaimer

HBT is presented as an ecosystem access and capacity mechanism, not as a speculative asset, investment product, deposit product, securities offering, crypto investment, or promise of return.
