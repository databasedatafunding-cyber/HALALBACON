# Early-Bird Onboarding Flow

## Goal

Make onboarding easy enough that a first-time visitor can understand it immediately.

## Step 1 — Choose Path

Cards:

1. Early-Bird Access
   - 12 months
   - Full Temporal Stack
   - Stripe Checkout

2. HBT Capacity Path
   - 1 HBT for 364 days
   - Verification required
   - Gift-card preference or continued HBT capacity subject to final terms

## Step 2 — Create Account

Fields:

- Email
- Password or magic link
- Name
- Country
- Preferred language

## Step 3 — Complete Profile

Fields:

- User type: builder, researcher, operator, investor, community participant, tenant, partner
- Interest: intelligence, shopping concierge, infrastructure proof, housing, all
- Risk/compliance acknowledgment

## Step 4 — Select Preference

For Early-Bird:

- Stripe checkout.
- Activate 12-month access after payment.

For HBT Path:

- Gift-card reimbursement preference.
- Keep as HBT access capacity preference.
- Shopping-credit adjustment preference where permitted.
- Shopping categories.
- Upload/verification fields if needed.

## Step 5 — Dashboard

Show:

- Access status
- Current signal
- Onboarding progress
- Shopping-list concierge
- Capacity status
- Proof ledger

## Step 6 — Admin Review

Admin can:

- Approve application
- Request more information
- Mark HBT verified
- Set access start/end dates
- Manage gift-card preferences
- Review shopping-list requests
