# HalalBacon Brand Voice

## Mood

Warm. Premium. Calm. Clear. Slightly funny. Values-first. Not angry.

## Visual World

- Sunrise eco-city.
- Rooftop garden.
- Pig mascot in sunglasses.
- Relaxed olive-tree vegetable mascot.
- Cream cards.
- Deep green surfaces.
- Gold accents.
- Soft 3D glass panels.
- Easy icons.

## Palette

- Deep Green: #073F2E
- Green Black: #02241D
- Emerald: #0F6B4A
- Gold: #B88A2B
- Soft Gold: #D8B867
- Cream: #F6EEDC
- Warm White: #FFFDF7
- Charcoal: #1E1E1E

## Typography

- Serif display: Fraunces or Playfair Display.
- Sans UI: Inter, Hanken Grotesk, or system sans.

## CTA Style

Use one primary CTA per section.

Examples:

- Enter the Signal
- Start Early-Bird Onboarding
- Choose Your Path
- Unlock Full Stack
- Reserve Early-Bird
- Choose HBT Access
- Add Shopping Request
- View Proof Ledger

## Required Tone Adjustments

Founder may use sharp political wording. Translate into safer product language:

Unsafe: “outside government control.”
Better: “independent from subsidy dependency and grant-cycle risk.”

Unsafe: “erase the sins of their wealth.”
Better: “avoid shifting today’s costs onto future generations.”

Unsafe: “nonprofit lobbyism filled with conflicts.”
Better: “reduce dependency on opaque grant and lobbying structures.”
