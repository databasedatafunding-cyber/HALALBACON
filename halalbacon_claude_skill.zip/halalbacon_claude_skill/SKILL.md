---
name: halalbacon-mvp-builder
description: Use this skill when asked to build, refactor, or extend the HalalBacon MVP: a premium 3D/Framer-style landing page, Supabase-auth user dashboard, Stripe Early-Bird subscriptions, HBT capacity/onboarding flows, gift-card preference handling, shopping-list concierge, and infrastructure-proof ledger. This skill is optimized for Next.js, TypeScript, Tailwind, Supabase, Stripe, and compliance-aware copy.
---

# HalalBacon MVP Builder Skill

## Mission

Build the HalalBacon MVP as a polished, premium, conversion-focused product:

- A 3D/Framer-style landing page that moves from dawn clarity into Early-Bird onboarding.
- A simple user dashboard with Supabase Auth.
- Stripe Checkout for fiat Early-Bird access packages.
- HBT capacity onboarding as a verified-access workflow, not a public speculative trading flow.
- A shopping-list concierge where users submit hard-to-find items and receive curated partner/off-platform purchase options.
- A proof layer for infrastructure, community, adaptive reuse, compute-heat reuse, and tenant-inflation absorption.

The product should feel like Apple keynote + calm ethical finance + warm eco-futuristic community infrastructure. It should be visually understandable to a non-technical user in under 30 seconds.

## Mandatory Brand Rules

Use this voice:

- Calm.
- Premium.
- Clear.
- Warm.
- Slightly satirical, never hostile.
- Values-first, but not preachy.
- Simple enough for a toddler to follow visually.

Use these words often:

- Signal
- Clarity
- Capacity
- Participation
- Proof
- Structure
- Community
- Discipline
- Reality
- Verified
- Early-Bird
- Temporal Stack

Avoid these words in public-facing copy unless the user explicitly requests them and legal review is assumed:

- Investment
- Yield
- Return
- ROI
- Pump
- Token upside
- Passive income
- Guaranteed
- Donation
- Securities
- Crypto investment
- Deposit product

If the user provides politically charged wording, convert it into compliance-safe product language. Do not erase the thesis; translate it into a safer public-facing frame.

## HBT / Capacity Compliance Guardrails

HBT must be presented as an ecosystem access and capacity mechanism. Do not present it as an investment, security, deposit, trading product, guaranteed return, or yield product.

Required public copy wherever HBT appears:

> HBT is presented as an ecosystem access and capacity mechanism, not as a speculative asset, investment product, deposit product, securities offering, crypto investment, or promise of return.

For the 364-day path, use language like:

- “capacity path”
- “verified capacity balance”
- “gift-card preference”
- “reimbursement preference, subject to final terms”
- “keep as HBT access capacity, subject to availability and terms”

Do not write “lend and earn” or “earn 10%.” Instead write:

> Choose a 364-day capacity path. At completion, select your preferred outcome: a gift-card reimbursement preference, a 0–10% shopping-credit adjustment where permitted by final terms, or continued HBT access capacity.

Add disclaimers that final terms must be published before launch and reviewed by counsel.

## Stripe Guardrails

Use Stripe for:

- Early-Bird 12-month fiat access package.
- Standard subscriptions.
- Art/support purchases.
- Concierge deposits or service fees if requested.

Do not process HBT/USDT directly through Stripe unless the user has confirmed Stripe policy/legal approval. For HBT, create an application/reservation workflow and admin verification fields.

## Product Architecture

Default stack:

- Next.js App Router
- TypeScript
- Tailwind CSS
- Supabase Auth
- Supabase Postgres
- Supabase Row-Level Security
- Stripe Checkout
- Stripe Customer Portal
- Stripe webhooks
- Server Actions or Route Handlers
- Optional Framer Motion / React Three Fiber for 3D-style landing interactions

Use the schema in `templates/supabase/schema.sql` unless the user provides a newer one.

## Pages to Generate

### Public

1. `/`
   - 3D/Framer-style landing page.
   - Hero: “Read the day before it is sold to you.”
   - Visual: pig mascot + relaxed olive-tree vegetable mascot in a sunrise eco-city world.
   - CTA 1: Enter the Signal.
   - CTA 2: Start Early-Bird Onboarding.

2. `/early-bird`
   - Two simple cards:
     - Early-Bird: 12 months to support the journey.
     - Capacity Path: 1 HBT for 364 days.
   - Four-step onboarding:
     1. Reserve
     2. Verify
     3. Maintain
     4. Unlock

3. `/pricing`
   - Fajr, Duhr, Asr, Full Stack.
   - Keep sacred order as Fajr → Duhr → Asr unless the user explicitly insists otherwise.

4. `/how-it-works`
   - Explain the temporal stack and algorithmic neutrality with icons and simple cards.

5. `/proof`
   - Infrastructure proof, building proof, community proof, energy proof.

### Authenticated

1. `/dashboard`
   - Today’s Structure.
   - Signal cards.
   - Membership status.
   - HBT capacity status.
   - Early-Bird progress.
   - Shopping-list concierge status.

2. `/dashboard/onboarding`
   - User selects Early-Bird or Capacity Path.
   - Collects profile, intent, country, accredited/institutional flag if needed, gift-card preference, shopping categories.

3. `/dashboard/shopping-list`
   - Add item requests such as vintage jacket, movie poster, collectible card, art object, furniture, electronics.
   - Allow budget, condition preference, authenticity requirements, notes, and urgency.

4. `/dashboard/billing`
   - Stripe subscription status.
   - Portal link.

5. `/dashboard/proof`
   - User-facing infrastructure ledger.
   - Show project progress and proof events.

### Admin

1. `/admin`
   - Applications
   - HBT capacity verification
   - Shopping-list concierge queue
   - Infrastructure projects
   - Brief publishing
   - Stripe events

## Required UX Simplicity

Every screen must follow this hierarchy:

1. One sentence explaining what this page does.
2. One obvious next action.
3. Three or fewer visible choices.
4. A progress indicator.
5. A plain-English reassurance line.

Use toddler-simple step labels:

- Pick your path.
- Tell us who you are.
- Choose your preference.
- We verify.
- You unlock.

## Landing Page Wireframe Sequence

Generate section-by-section, not as one giant wall:

1. Hero: “Read the day before it is sold to you.”
2. Dawn Signal: Fajr pre-bell reality brief.
3. Great Divide: noise versus clarity.
4. Temporal Stack: Fajr → Duhr → Asr.
5. Product Surface: daily dashboard preview.
6. Algorithmic Neutrality: ingest → decompose → refine → publish.
7. Dispatch No. 001: founder story, softened.
8. Proof in Place: city/community/infrastructure map.
9. Access by Capacity: HBT capacity card.
10. Early-Bird Onboarding: choose 12 months or capacity path.

## Data Model Summary

Core tables:

- profiles
- access_packages
- user_access
- onboarding_applications
- hbt_capacity_records
- gift_card_preferences
- shopping_lists
- shopping_list_items
- concierge_matches
- briefs
- brief_vectors
- infrastructure_projects
- proof_events
- art_support_orders
- stripe_customers
- stripe_subscriptions
- stripe_checkout_sessions
- stripe_webhook_events
- audit_events

Use Row-Level Security. Users can read and update only their own records. Admins can manage all records.

## Stripe Implementation Requirements

Create:

- `POST /api/stripe/create-checkout-session`
- `POST /api/stripe/create-portal-session`
- `POST /api/stripe/webhook`

Environment variables:

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
- `NEXT_PUBLIC_APP_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Checkout metadata must include:

- `user_id`
- `package_code`
- `access_type`

Webhook should handle:

- `checkout.session.completed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `invoice.paid`
- `invoice.payment_failed`

## Supabase Requirements

Use Supabase Auth. Create RLS policies for every table.

Never expose `SUPABASE_SERVICE_ROLE_KEY` to the browser.

Use server-only code for:

- Admin actions.
- Stripe webhook handling.
- Updating paid access.
- HBT verification.

## Output Claude Should Produce

When invoked to create the MVP, produce:

1. File tree.
2. Installation commands.
3. `.env.example`.
4. Supabase schema and seed instructions.
5. Stripe product setup instructions.
6. Core pages/components.
7. API routes.
8. RLS policies.
9. Admin workflow.
10. Testing checklist.
11. Deployment checklist.

## Reference Files

Use these files for details:

- `references/product-brief.md`
- `references/brand-voice.md`
- `references/landing-copy.md`
- `references/onboarding-flow.md`
- `references/architecture.md`
- `templates/supabase/schema.sql`
- `templates/stripe/products.md`
- `templates/next/file-tree.md`
- `templates/env.example`

## Final Quality Bar

The MVP should feel:

- Premium enough to show an investor.
- Simple enough for a first-time user.
- Structured enough for a developer to build.
- Safe enough that HBT is not accidentally positioned as a public investment offer.
