/* ============================================================
   HalalBacon — Figma Style & Frame Generator
   Creates native color styles, text styles, and a seed Hero frame.
   ------------------------------------------------------------
   HOW TO RUN (2 min):
   1. Figma desktop → Menu → Plugins → Development → New plugin…
   2. "Run last plugin" → choose an empty figma plugin, name it "HB Generator".
   3. Open the generated manifest folder; replace code.js with THIS file.
      (manifest.json needs:  { "name":"HB Generator","id":"hb","api":"1.0.0",
        "main":"code.js","editorType":["figma"] }  — no UI needed.)
   4. Run the plugin. It builds styles + a Hero frame on the current page.
   Note: Fraunces may not be installed in Figma — the script falls back to
   Inter for headlines and logs a note. Install Fraunces for exact type.
   ============================================================ */

const PALETTE = {
  "HB/Base":       "#08090A",
  "HB/Surface":    "#111714",
  "HB/Surface-2":  "#161E1A",
  "HB/Green":      "#0F6B4A",
  "HB/Emerald":    "#1B8A63",
  "HB/Gold":       "#C99A3A",
  "HB/Gold Soft":  "#E3C684",
  "HB/Ivory":      "#F4EFE3",
  "HB/Muted":      "#9AA39C",
  "HB/Clay":       "#C56A59",
};

function hexToRgb(hex){
  const h = hex.replace("#","");
  return { r: parseInt(h.substr(0,2),16)/255, g: parseInt(h.substr(2,2),16)/255, b: parseInt(h.substr(4,2),16)/255 };
}
const solid = hex => [{ type:"SOLID", color: hexToRgb(hex) }];

async function loadFonts(){
  const inter = ["Regular","Medium","Semi Bold","Bold"];
  for (const s of inter){ await figma.loadFontAsync({ family:"Inter", style:s }); }
  let serif = { family:"Inter", style:"Semi Bold" };
  try { await figma.loadFontAsync({ family:"Fraunces", style:"Semi Bold" }); serif = { family:"Fraunces", style:"Semi Bold" }; }
  catch(e){ console.log("Fraunces not installed — using Inter for headlines. Install Fraunces for exact type."); }
  return { serif };
}

function makeText(parent, chars, o){
  const t = figma.createText();
  t.fontName = o.font;
  t.characters = chars;
  t.fontSize = o.size;
  t.fills = solid(o.color);
  if (o.width){ t.resize(o.width, t.height); t.textAutoResize = "HEIGHT"; }
  if (o.lh) t.lineHeight = { value:o.lh, unit:"PERCENT" };
  if (o.ls != null) t.letterSpacing = { value:o.ls, unit:"PIXELS" };
  t.x = o.x; t.y = o.y;
  parent.appendChild(t);
  return t;
}

async function run(){
  const { serif } = await loadFonts();
  const reg  = { family:"Inter", style:"Regular" };
  const med  = { family:"Inter", style:"Medium" };
  const semi = { family:"Inter", style:"Semi Bold" };
  const bold = { family:"Inter", style:"Bold" };

  // ---- color styles ----
  for (const [name,hex] of Object.entries(PALETTE)){
    const s = figma.createPaintStyle();
    s.name = name; s.paints = solid(hex);
  }

  // ---- text styles ----
  const mkTS = (name, font, size, lh, ls) => {
    const ts = figma.createTextStyle();
    ts.name = name; ts.fontName = font; ts.fontSize = size;
    ts.lineHeight = { value:lh, unit:"PERCENT" };
    if (ls != null) ts.letterSpacing = { value:ls, unit:"PIXELS" };
    return ts;
  };
  mkTS("HB/Display", serif, 54, 100, -2);
  mkTS("HB/H2",      serif, 32, 104, -1.2);
  mkTS("HB/H3",      serif, 22, 110, -0.6);
  mkTS("HB/Body",    reg,   16, 150, 0);
  mkTS("HB/Caption", med,   12, 140, 0);
  mkTS("HB/Eyebrow", bold,  11, 120, 1.6);

  // ---- seed Hero frame ----
  const F = figma.createFrame();
  F.name = "HalalBacon / Hero — Dark";
  F.resize(1440, 812);
  F.fills = solid("#08090A");
  F.cornerRadius = 0;
  figma.currentPage.appendChild(F);

  // ambient glow
  const glow = figma.createEllipse();
  glow.resize(900, 640); glow.x = 520; glow.y = -180;
  glow.fills = [{ type:"SOLID", color:hexToRgb("#1B8A63"), opacity:0.16 }];
  glow.effects = [{ type:"LAYER_BLUR", radius:120, visible:true }];
  F.appendChild(glow);

  // pill
  const pill = figma.createFrame();
  pill.name = "pill"; pill.resize(300, 30); pill.x = 96; pill.y = 120;
  pill.cornerRadius = 100; pill.fills = [{ type:"SOLID", color:hexToRgb("#C99A3A"), opacity:0.1 }];
  pill.strokes = [{ type:"SOLID", color:hexToRgb("#C99A3A"), opacity:0.28 }];
  F.appendChild(pill);
  makeText(F, "Independent · in stealth since 2019", { x:118, y:127, size:12, font:semi, color:"#E3C684" });

  // headline
  makeText(F, "Read the day\nbefore it's sold to you.", { x:94, y:172, size:64, font:serif, color:"#F4EFE3", lh:98, ls:-2.4, width:760 });

  // lead + tagline
  makeText(F, "Empirical, source-filtered intelligence — so you can find the truth for yourself, not be told how to feel about it.", { x:96, y:356, size:18, font:reg, color:"#9AA39C", lh:150, width:480 });
  makeText(F, "Finance without riba. Media without outrage. Housing without speculation.", { x:96, y:436, size:17, font:semi, color:"#F4EFE3", lh:140, width:480 });

  // buttons
  const btn = figma.createFrame();
  btn.name = "Button / Primary"; btn.resize(170, 48); btn.x = 96; btn.y = 500;
  btn.cornerRadius = 13; btn.fills = solid("#E3C684");
  F.appendChild(btn);
  makeText(F, "Request access", { x:118, y:515, size:14, font:bold, color:"#1C1405" });

  const btn2 = figma.createFrame();
  btn2.name = "Button / Ghost"; btn2.resize(150, 48); btn2.x = 280; btn2.y = 500;
  btn2.cornerRadius = 13; btn2.fills = [{ type:"SOLID", color:hexToRgb("#F4EFE3"), opacity:0.04 }];
  btn2.strokes = [{ type:"SOLID", color:hexToRgb("#F4EFE3"), opacity:0.16 }];
  F.appendChild(btn2);
  makeText(F, "See the evidence", { x:300, y:515, size:14, font:semi, color:"#F4EFE3" });

  // brief card
  const card = figma.createFrame();
  card.name = "Card / Dawn Signal"; card.resize(420, 300); card.x = 920; card.y = 256;
  card.cornerRadius = 18; card.fills = solid("#161E1A");
  card.strokes = [{ type:"SOLID", color:hexToRgb("#F4EFE3"), opacity:0.16 }];
  F.appendChild(card);
  makeText(F, "Dawn Signal · Fajr", { x:944, y:282, size:12, font:med, color:"#9AA39C" });
  makeText(F, "04:48 EST", { x:1244, y:282, size:14, font:serif, color:"#E3C684" });
  makeText(F, "Energy   Pressure remains supply-driven        +2.1%", { x:944, y:330, size:13, font:reg, color:"#F4EFE3", width:372 });
  makeText(F, "Rates    Policy path unchanged overnight        0 bps", { x:944, y:366, size:13, font:reg, color:"#F4EFE3", width:372 });
  makeText(F, "Housing  Permit velocity below replacement     −6.4%", { x:944, y:402, size:13, font:reg, color:"#F4EFE3", width:372 });
  makeText(F, "BIAS RESIDUE INDEX", { x:944, y:470, size:11, font:semi, color:"#9AA39C", ls:1.2 });
  makeText(F, "8%", { x:1284, y:466, size:16, font:serif, color:"#E3C684" });
  const track = figma.createRectangle();
  track.resize(372, 6); track.x = 944; track.y = 500; track.cornerRadius = 3;
  track.fills = [{ type:"SOLID", color:hexToRgb("#F4EFE3"), opacity:0.1 }];
  F.appendChild(track);
  const fill = figma.createRectangle();
  fill.resize(40, 6); fill.x = 944; fill.y = 500; fill.cornerRadius = 3;
  fill.fills = solid("#1B8A63");
  F.appendChild(fill);

  figma.viewport.scrollAndZoomIntoView([F]);
  figma.notify("HalalBacon: 10 color styles, 6 text styles + Hero frame created.");
  figma.closePlugin();
}

run();
