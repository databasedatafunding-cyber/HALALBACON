# HalalBacon — Claude Design Setup (paste-ready)

Fill the "Set up your design system" form with the blocks below. Your GitHub repo (`databasedatafunding-cyber/HALALBACON`) is already connected — section 2 tells Claude which files define the system.

---

## ▸ PASTE INTO: *Company name and blurb*

**Name:** HalalBacon — Design System (HBDS)

**Blurb:**
HalalBacon is a halal, ethical participation platform: finance without riba, media without outrage, housing without speculation. It combines unbiased dawn intelligence, anti-riba community loans, real-asset deployment, and affordable-housing retrofit. The design language is premium, calm, institutional, and dark-mode-first — Apple-keynote restraint meets luxury fintech. Every screen answers three questions: what is this, why does it matter, what do I do next.

---

## ▸ PASTE INTO: *Examples of your design system and products*

Point Claude at these files in the connected repo — they define the component library and the two themes:

- **`early-bird.html`** — dark-mode conversion/onboarding page. The canonical reference for the **dark theme**, hero offer card, persona module, pricing matrix (30% / 10% early-bird), sticky CTA bar, reserve modal, countdown.
- **`index.html`** — light-mode MVP: hero, dawn-brief terminal card, Temporal Stack, De-Noising Protocol, Dispatch article, campaign cards.
- **`prospectus.html`** — interactive 10-scene prospectus (scroll-snap deck, animated counters, capacity calculator).
- **`knowledge.html`** — knowledge center: glossary, FAQ, compare modules, poster gallery.

**Component vocabulary to reuse:** hero + offer card · brief/terminal card · temporal-stack cards · pricing matrix · capacity module · persona cards · steps row · trust strip · campaign/fund cards · dispatch article · reserve modal.

---

## ▸ PASTE INTO: *Add fonts, logos and assets*

**Type**
- **Fraunces** — serif, headlines only (optical, tight tracking `-0.038em`, line-height ~1.0).
- **Hanken Grotesk** — geometric sans for all UI/body/data. **Inter** as fallback.

**Logo:** HalalBacon "root-leaf" mark (upload PNG + SVG). Clear-space = cap height; never recolor outside the palette; never place on busy photography without a scrim.

**Color tokens — Light (editorial) & Dark (product, default):**

| Token | Light | Dark |
|:--|:--|:--|
| background | `#F6EEDC` cream | `#08090A` near-black |
| surface | `#FFFDF7` | `#111714` graphite-green |
| primary green | `#073F2E` / `#0F6B4A` | `#0F6B4A` / `#1B8A63` |
| gold | `#B88A2B` | `#C99A3A` |
| soft gold | `#D8B867` | `#E3C684` |
| text | `#1E1E1E` ink | `#F4EFE3` ivory |
| muted text | `#6c6f63` | `#9AA39C` |
| reserved red | `#B84A3A` (old-model only) | `#C56A59` |

Radii `12 / 18 / 28`. Soft shadows, deep contrast, glassmorphism only on nav/sticky bars. Motion: `cubic-bezier(.22,1,.36,1)`, orient-don't-perform.

---

## ▸ PASTE INTO: *Any other notes*

**Principles** — Clarity over decoration. Fewer words, stronger hierarchy, one obvious primary action per screen. Break complex finance into cards, steps, and decision trees — never walls of text. Compliance is invisible, not scary. Onboarding should feel like opening an Apple Card, not a government form.

**Voice** — Direct, sharp, confident, lightly witty, never hype. Approved lines:
- "Stop donating. Start participating."
- "Finance without riba. Media without outrage. Housing without speculation."
- "Ethical capital should still perform."
- "Read the day before it's sold to you."

**Halal positioning** — Frame *halal* as ethical, transparent, anti-riba, anti-exploitation, dignity-driven. Use Islamic terms with restraint and translate them (e.g., *riba* = interest/usury). No mosque/ornament/calligraphy themes unless asked. Define Arabic terms for Muslims and non-Muslims alike.

**Compliance language** — Use: participation capacity, verified balance, membership, utility, proof. Avoid: invest, returns, yield, guaranteed, passive income, token price. Always retain: *Invitation-only · Preliminary · Not legal, tax, securities, crypto, or investment advice.* Separate accredited vs. non-accredited flows; keep community loans under 364 days distinct from long-term products.

**Conversion rules (for landing/onboarding screens)** — Lead with the offer + anchored saving. Repeat one primary CTA ("Claim 30%"). Add urgency (countdown, limited seats), risk reversal ("no card to reserve"), and persona relevance. Route subscription vs. HBT-participation paths from a single decision point.

---

## ▸ Image-generation prompt pack (for hero renders & mockups)

**Always append:** *hyper-realistic, photorealistic, premium Apple UI/UX, cinematic lighting, high resolution, realistic materials, minimalist composition, modern halal fintech startup, luxury product render, dark-mode interface, clean typography, deep green / muted gold / ivory / graphite palette.*

**Always avoid:** *cartoon, anime, clipart, cheap 3D, generic blockchain icons, fake Arabic calligraphy, excessive gold, mosque background, neon crypto-casino visuals.*

1. **Hero phone** — "Photorealistic iPhone floating on a graphite-black surface, screen showing a calm dark-mode finance app: a single dawn news brief with a clean bias-score meter, muted gold accents, deep-green header, cinematic soft side light, shallow depth of field."
2. **Dashboard** — "Ultra-realistic desktop monitor on a dark walnut desk showing a minimalist ethical-finance dashboard: community-loan cards, real-asset allocation, transparent exit timeline, ivory text on near-black, muted gold data accents, soft window light."
3. **Investor portal** — "Photorealistic laptop screen, dark institutional portal: accredited-investor flow, allocation summary, compliance status as a quiet checkmark, premium glassmorphism panel, cinematic low-key lighting."
4. **Housing retrofit** — "Cinematic photoreal render of a retrofit-first low-rise building at golden hour with solar roofing and greenery, warm and dignified, no people, architectural-photography quality."
5. **Community finance flow** — "Clean dark-mode mobile flow, three stacked screens: choose participation path → verify balance → standing confirmed, muted gold progress, deep-green accents, Apple-keynote product shot on seamless graphite background."

---

## ▸ Addendum — Studio strategy & gaps to close

**Strategic frame (the studio thesis).** HalalBacon is the first product of a venture studio launching startups engineered to lower users' costs over time — *technology-driven deflation*. Treat **savings as a first-class value prop**: wherever possible, show the cost going **down** — fees avoided, riba avoided, dollars saved, price-per-unit falling. Five layers: media/news · anti-riba community loans (<364 days) · real-asset deployment · affordable-housing retrofit · founder-led anti-speculative infrastructure. Not charity — ethical capital that still performs.

**Three gaps the brief doesn't yet cover:**

1. **Make the deflation visible.** Cost reduction is the studio's entire thesis, yet no screen *quantifies* it. Ship a recurring "what this saves you" module — dollars/fees avoided, a price-down-over-time line, a riba-avoided counter. *(Now built: `deflation-module.html`.)* Show it; don't assert it.
2. **Accessibility + fallbacks.** Lock WCAG-AA contrast on dark (watch muted-gold-on-green specifically), keep a light variant for email/print/pitch exports, and honor reduced-motion + RTL — you mix Arabic terms and may localize.
3. **One source of truth.** Maintain a single `design-tokens` file (light + dark) that web, app, and deck all import so nothing drifts; define empty / loading / error / success states once, then reuse.
